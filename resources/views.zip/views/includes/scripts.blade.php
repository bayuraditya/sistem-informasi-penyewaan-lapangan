<script src="/assets/js/app.js"></script>
<script src="/assets/js/pages/dashboard.js"></script>
<script src="/assets/js/extensions/datatables.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"
    integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js@9.0.1/public/assets/styles/choices.min.css" />
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js">
</script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap.min.js">
</script>
<script type="text/javascript" charset="utf8"
    src="https://cdn.datatables.net/fixedheader/3.2.3/js/dataTables.fixedHeader.min.js"></script>
<script type="text/javascript" charset="utf8"
    src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" charset="utf8"
    src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap.min.js"></script>
{{-- <script>
    $(document).ready(function() {
        var table = $('#table1').DataTable({
            responsive: true,
            order: [
                [3, 'desc']
            ],
        });

        var tableTransaksi = $('#table-transaksi').DataTable({
            responsive: true,
            order: [
                [4, 'desc']
            ],
        });

        new $.fn.dataTable.FixedHeader(tableTransaksi);

        new $.fn.dataTable.FixedHeader(table);
    });
</script> --}}
