<link rel="stylesheet" href="/assets/css/main/app.css">
<link rel="stylesheet" href="/assets/css/main/app-dark.css">
<link rel="shortcut icon" href="/assets/images/logo/favicon.svg" type="image/x-icon">
<link rel="shortcut icon" href="/assets/images/logo/favicon.png" type="image/png">

<link rel="stylesheet" href="/assets/css/shared/iconly.css">
<link rel="stylesheet" href="/assets/css/pages/fontawesome.css">
<link rel="stylesheet" href="/assets/css/pages/datatables.css">
{{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.2.3/css/fixedHeader.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.dataTables.min.css" /> --}}
